const socket = io();

const rollBtn = document.getElementById('rollBtn');
const diceVal = document.getElementById('dice-val');
const turnBadge = document.getElementById('turn-badge');
const statusMsg = document.getElementById('status-msg');

let myTurn = 'green';
let myRoll = 0;

const greenPath = [
    [7,2], [7,3], [7,4], [7,5], [7,6], [6,7], [5,7], [4,7], [3,7], [2,7], [1,7], 
    [1,8], [1,9], [2,9], [3,9], [4,9], [5,9], [6,9], [7,10],[7,11],[7,12],[7,13],[7,14],[7,15], 
    [8,15], [9,15], [9,14],[9,13],[9,12],[9,11],[9,10], [10,9],[11,9],[12,9],[13,9],[14,9],[15,9], 
    [15,8], [15,7], [14,7],[13,7],[12,7],[11,7],[10,7], [9,6], [9,5], [9,4], [9,3], [9,2], [9,1], 
    [8,1], [8,2], [8,3], [8,4], [8,5], [8,6], [8,7]
];

function getCoords(color, step) {
    if (step < 0) return null;
    if (step >= 56) return greenPath[56]; // Home coordinates

    const [r, c] = greenPath[step];
    if (color === 'green') return [r, c];
    if (color === 'yellow') return [c, 16 - r];
    if (color === 'blue') return [16 - r, 16 - c];
    if (color === 'red') return [16 - c, r];
}

socket.on('stateUpdate', (data) => { myTurn = data.turn; updateUI(myTurn); });
socket.on('turnChange', (data) => { 
    myTurn = data.newTurn; updateUI(myTurn); 
    rollBtn.disabled = false; rollBtn.style.opacity = "1"; rollBtn.innerText = "ROLL DICE"; 
});

socket.on('turnMessage', (data) => {
    statusMsg.innerText = data.msg;
    if (data.msg.includes("Roll Again")) {
        rollBtn.disabled = false; rollBtn.style.opacity = "1"; rollBtn.innerText = "BONUS ROLL!";
    }
});

socket.on('gameWon', (data) => {
    statusMsg.innerText = `GAME OVER! ${data.winner.toUpperCase()} WINS!`;
    turnBadge.innerText = "WINNER!";
    rollBtn.disabled = true;
    rollBtn.style.background = "gold";
    rollBtn.innerText = "🏆";
    
    // Show Crown
    const crown = document.querySelector(`.${data.winner}-house .winner-crown`);
    if(crown) crown.classList.add('show-crown');
});

rollBtn.addEventListener('click', () => { socket.emit('requestRoll'); });

socket.on('diceRolled', (data) => {
    diceVal.innerText = data.roll; myRoll = data.roll;
    statusMsg.innerText = `${data.player.toUpperCase()} rolled ${data.roll}`;
    if (data.player === myTurn) {
        rollBtn.disabled = true; rollBtn.style.opacity = "0.5"; rollBtn.innerText = "...";
        checkMoves(data.player, data.roll);
    }
});

socket.on('updatePawnPosition', (data) => {
    const pawn = document.getElementById(data.id);
    pawn.dataset.step = data.step;
    pawn.classList.remove('active');

    if (data.step >= 0) {
        const [r, c] = getCoords(data.color, data.step);
        document.querySelector('.board').appendChild(pawn);
        pawn.style.gridArea = `${r} / ${c}`;
        
        // FINISHED PAWN VISUAL
        if(data.step === 56) {
            pawn.classList.add('finished');
        }
    } else {
        const boxes = document.querySelectorAll(`.${data.color}-house .pawn-box`);
        for (let box of boxes) {
            if (box.children.length === 0) { box.appendChild(pawn); break; }
        }
        pawn.style.gridArea = 'auto'; 
    }
});

function checkMoves(color, roll) {
    const pawns = document.querySelectorAll(`.pawn[data-color="${color}"]`);
    let movesFound = false;

    pawns.forEach(pawn => {
        const step = parseInt(pawn.dataset.step || "-1");
        // Don't move if already finished (56)
        if(step === 56) return;

        if (step === -1 && roll === 6) {
            pawn.classList.add('active'); movesFound = true;
        } else if (step >= 0 && step + roll <= 56) {
            pawn.classList.add('active'); movesFound = true;
        }
    });

    if (!movesFound) {
        statusMsg.innerText = `Rolled ${roll}. No moves! Passing turn...`;
        setTimeout(() => { socket.emit('passTurn'); }, 1000); 
    } else {
        statusMsg.innerText = `Rolled ${roll}. Select a pawn to move.`;
    }
}

document.addEventListener('click', (e) => {
    if (e.target.classList.contains('active')) {
        const pawn = e.target;
        const currentStep = parseInt(pawn.dataset.step || "-1");
        let nextStep = (currentStep === -1) ? 0 : currentStep + myRoll;
        socket.emit('pawnMove', { id: pawn.id, color: pawn.dataset.color, step: nextStep });
        document.querySelectorAll('.pawn').forEach(p => p.classList.remove('active'));
    }
});

function updateUI(turn) {
    turnBadge.innerText = `${turn.toUpperCase()}'S TURN`;
    turnBadge.className = `turn-badge bg-${turn}`;
    statusMsg.innerText = "Waiting for roll...";
    diceVal.innerText = "🎲";
}