const express = require('express');
const http = require('http');
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

let players = {
    green:  { pawns: [-1, -1, -1, -1], finished: 0 },
    yellow: { pawns: [-1, -1, -1, -1], finished: 0 },
    blue:   { pawns: [-1, -1, -1, -1], finished: 0 },
    red:    { pawns: [-1, -1, -1, -1], finished: 0 }
};

let gameState = {
    turnIndex: 0,
    turnOrder: ['green', 'yellow', 'blue', 'red'],
    diceValue: 0,
    isWaitingForMove: false,
    sixCount: 0,
    winner: null // Track if someone won
};

const greenPath = [
    [7,2], [7,3], [7,4], [7,5], [7,6], [6,7], [5,7], [4,7], [3,7], [2,7], [1,7], 
    [1,8], [1,9], [2,9], [3,9], [4,9], [5,9], [6,9], [7,10],[7,11],[7,12],[7,13],[7,14],[7,15], 
    [8,15], [9,15], [9,14],[9,13],[9,12],[9,11],[9,10], [10,9],[11,9],[12,9],[13,9],[14,9],[15,9], 
    [15,8], [15,7], [14,7],[13,7],[12,7],[11,7],[10,7], [9,6], [9,5], [9,4], [9,3], [9,2], [9,1], 
    [8,1], [8,2], [8,3], [8,4], [8,5], [8,6], [8,7]
];
const safeZones = ["7,2", "2,9", "9,14", "14,7", "3,7", "7,13", "13,9", "9,3"];

function getCoords(color, step) {
    if (step < 0) return null;
    if (step >= greenPath.length) return greenPath[56]; 
    const [r, c] = greenPath[step];
    if (color === 'green') return {r, c};
    if (color === 'yellow') return {r: c, c: 16 - r};
    if (color === 'blue') return {r: 16 - r, c: 16 - c};
    if (color === 'red') return {r: 16 - c, c: r};
}

io.on('connection', (socket) => {
    console.log('Player connected:', socket.id);
    socket.emit('stateUpdate', { turn: gameState.turnOrder[gameState.turnIndex] });

    socket.on('requestRoll', () => {
        if (gameState.isWaitingForMove || gameState.winner) return;

        const roll = Math.floor(Math.random() * 6) + 1;
        gameState.diceValue = roll;
        const currentPlayer = gameState.turnOrder[gameState.turnIndex];

        if (roll === 6) {
            gameState.sixCount++;
            if (gameState.sixCount === 3) {
                io.emit('diceRolled', { roll: 6, player: currentPlayer });
                io.emit('turnMessage', { msg: "Three 6s! Turn Lost." });
                setTimeout(nextTurn, 2000);
                return;
            }
        } else {
            gameState.sixCount = 0;
        }

        gameState.isWaitingForMove = true;
        io.emit('diceRolled', { roll: roll, player: currentPlayer });
    });

    socket.on('pawnMove', (data) => {
        const { id, color, step } = data;
        const pawnIndex = parseInt(id.charAt(1)) - 1;
        
        // Track old step to check if it JUST finished
        const oldStep = players[color].pawns[pawnIndex];
        players[color].pawns[pawnIndex] = step;

        // Check Finished
        if (step === 56 && oldStep !== 56) {
            players[color].finished++;
            // Check Win Condition
            if (players[color].finished === 4) {
                gameState.winner = color;
                io.emit('gameWon', { winner: color });
                io.emit('updatePawnPosition', data); // Move final pawn
                return; // Stop game
            }
        }

        let killHappened = false;
        // Collision
        if (step >= 0 && step < 51) { 
            const myPos = getCoords(color, step);
            const posKey = `${myPos.r},${myPos.c}`;

            if (!safeZones.includes(posKey)) {
                gameState.turnOrder.forEach(enemyColor => {
                    if (enemyColor !== color) {
                        players[enemyColor].pawns.forEach((enemyStep, idx) => {
                            if (enemyStep !== -1 && enemyStep !== 56) { // Don't kill home pawns 
                                const enemyPos = getCoords(enemyColor, enemyStep);
                                if (enemyPos.r === myPos.r && enemyPos.c === myPos.c) {
                                    players[enemyColor].pawns[idx] = -1;
                                    killHappened = true;
                                    io.emit('updatePawnPosition', { id: `${enemyColor.charAt(0)}${idx + 1}`, color: enemyColor, step: -1 });
                                    io.emit('turnMessage', { msg: `Boom! ${enemyColor} sent home!` });
                                }
                            }
                        });
                    }
                });
            }
        }

        io.emit('updatePawnPosition', data);

        if (gameState.diceValue === 6 || killHappened) {
            gameState.isWaitingForMove = false;
            io.emit('turnMessage', { msg: killHappened ? "Enemy Killed! Roll Again!" : "Rolled 6! Roll Again!" });
        } else {
            nextTurn();
        }
    });

    socket.on('passTurn', () => { nextTurn(); });

    function nextTurn() {
        if(gameState.winner) return;
        gameState.turnIndex = (gameState.turnIndex + 1) % 4;
        gameState.isWaitingForMove = false;
        gameState.sixCount = 0;
        io.emit('turnChange', { newTurn: gameState.turnOrder[gameState.turnIndex] });
    }
});

server.listen(3002, () => {
    console.log('✅ Server running on http://localhost:3002');
});